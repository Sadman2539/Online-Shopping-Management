from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_page, name='home'),
    path('dashboard/', views.home, name='dashboard'),
    path('customer/<str:pk_test>/', views.customer, name='customer'),
    path('products/', views.products, name='products'),
    # path('update_product/<str:pk_test>/', views.updateProduct, name='update_product'),
    # path('delete_product/<str:pk_test>/', views.deleteProduct, name='delete_product'),
    path('create_order/<str:pk>/', views.createOrder, name='create_order'),
    path('update_order/<str:pk>/', views.updateOrder, name='update_order'),
    path('delete_order/<str:pk>/', views.deleteOrder, name='delete_order'),

]
